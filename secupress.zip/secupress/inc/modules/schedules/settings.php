<?php
defined( 'ABSPATH' ) or die( 'Something went wrong.' );

$this->load_plugin_settings( 'schedules-backups' );
$this->load_plugin_settings( 'schedules-scan' );
$this->load_plugin_settings( 'schedules-file-monitoring' );
