<?php if(! WsdUtil::canLoad()) { return; } ?>
<?php if(! WsdUtil::isAdministrator()) { return; } ?>
<div id="wsd-banner-rotator" class="wsdplugin-overflow">
    <div style="width:800px; margin: 0 auto;">
        <a href="//www.acunetix.com/" style="border:none;text-decoration: none;" target="_blank" title="Visit www.acunetix.com (opens in a new window/tab)">
            <img src="//www.acunetix.com/assets/banner.jpg" alt="" title=""/>
        </a>
    </div>
</div>
