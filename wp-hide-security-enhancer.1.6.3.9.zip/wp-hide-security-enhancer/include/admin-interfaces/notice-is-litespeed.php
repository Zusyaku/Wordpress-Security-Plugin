<?php
        if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>

    <p><span class="dashicons dashicons-flag error"></span> <?php _e( "Your site runs on LiteSpeed ! Before starting, ensure your server is properly configured and it processes the .htaccess file, or there might be layout and functionality breaks.", 'wp-hide-security-enhancer' ) ?> <?php _e( "For more details check at", 'wp-hide-security-enhancer' ) ?> <a target="_blank" href="https://www.wp-hide.com/setup-wp-hide-on-litespeed/">Setup WP Hide on LiteSpeed</a></p>
