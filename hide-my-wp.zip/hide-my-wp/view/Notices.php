<div class="hmw_notice <?php echo $type ?>"><?php echo $message ?></div>

