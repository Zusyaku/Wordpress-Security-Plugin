<?php

return [
	'title' => __( 'Change Content Directory', 'better-wp-security' ),
];
