<?php
ITSEC_Core::get_scheduler()->unschedule( 'backup' );