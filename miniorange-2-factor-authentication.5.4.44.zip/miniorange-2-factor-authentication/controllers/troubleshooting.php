<?php
	
	global $moWpnsUtility,$mo2f_dirName;

	include $mo2f_dirName . 'views'.DIRECTORY_SEPARATOR.'troubleshooting.php';