<?php
include_once $mo2f_dirName . 'views'.DIRECTORY_SEPARATOR.'backup'.DIRECTORY_SEPARATOR.'backup_created_report.php';